"""

:copyright: Copyright since 2006 by Oliver Schoenborn, all rights reserved.
:license: BSD, see LICENSE_BSD_Simple.txt for details.

"""

def getRootTopicSpec():
    """If using kwargs protocol, then root topic takes no args."""
    argsDocs = {}
    reqdArgs = ()
    return argsDocs, reqdArgs

